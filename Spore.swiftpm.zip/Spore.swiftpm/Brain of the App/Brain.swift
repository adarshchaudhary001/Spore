import SwiftUI
import Vision
import FoundationModels

@MainActor
@Observable
class Brain {
    var isProcessing = false
    var lastError: String?
    var generatedLayout: Layout?
    
    // Holds custom notes before the card is saved
    var currentGlossaryNotes: [GlossaryNote] = []
    
    // Holds stats before the card is saved
    var currentFlipCount: Int = 0
    var currentHasOpenedGlossary: Bool = false
    var currentIsFullyGrown: Bool = false
    
    // Persistence Array
    var savedDeck: [SavedFlashcard] = []
    
    private let modelSession: LanguageModelSession
    
    init() {
        let systemPrompt = """
        You are an expert Academic Tutor AI. Your goal is to convert raw, potentially messy notes into accurate, beautiful Flashcards.
        
        **CRITICAL INSTRUCTION 1: BE A FACT-CHECKING EDITOR**
        - Use the notes provided by the student to get the gist and basic information to know what the note is about.
        - However, you MUST generate CORRECT information only.
        - The user's notes may contain factual inaccuracies, typos, OCR errors, or shorthand.
        - You MUST fact-check the content and correct all factual inaccuracies. Do not repeat incorrect facts from the notes.
        - Correct spelling and grammar, and expand abbreviations. Refine the text to be academic and professional.
        
        **CRITICAL INSTRUCTION 2: CLASSIFY SUBJECT THEME**
        Select `VisualTheme` based on the subject matter:
        - `technology`: Computer Science, Math, Physics, Engineering.
        - `nature`: Biology, Anatomy, Chemistry, Geography.
        - `humanities`: History, Literature, Philosophy, Sociology.
        - `business`: Economics, Finance, Marketing, Law, Management.
        - `creative`: Music, Art, Design, Architecture, Theater.
        - `standard`: General topics, or if unsure.
        
        **CRITICAL INSTRUCTION 3: DETERMINE LAYOUT INTENT**
        Select `Intent` based on the information structure:
        - `processFlow`: Sequences, algorithms, cycles, steps.
        - `historicalTimeline`: Dates, years, chronological events.
        - `comparison`: "Vs", "Difference between", Pros/Cons.
        - `conceptDefinition`: General facts, lists, or definitions.
        
        **CRITICAL INSTRUCTION 4: EXTRACT GLOSSARY KEYWORDS**
        - Identify 3-5 important vocabulary terms present in the text.
        - Extract them into the `keywords` array along with a short, 1-sentence definition for each.
        
        **Step 5: Generate Content**
        - Title: Clear and Descriptive.
        - KeyPoints: 3-5 concise, corrected bullet points.
        - Mnemonics: A clever memory aid.
        - Keywords: Your extracted glossary terms.
        """
        
        self.modelSession = LanguageModelSession(instructions: systemPrompt)
        loadFromDisk()
    }
    
    // MARK: - Process Inputs
    func process(_ input: Any) async {
        isProcessing = true
        lastError = nil
        currentGlossaryNotes = []
        currentFlipCount = 0
        currentHasOpenedGlossary = false
        currentIsFullyGrown = false
        
        do {
            var textToAnalyze = ""
            
            if let text = input as? String {
                textToAnalyze = text
            } else if let image = input as? UIImage {
                textToAnalyze = try await performOCR(on: image)
            }
            
            let layout = try await generateBlueprint(from: textToAnalyze)
            self.generatedLayout = layout
            self.isProcessing = false
        } catch {
            self.lastError = error.localizedDescription
            self.isProcessing = false
        }
    }
    
    // MARK: - Persistence Logic
    func saveCurrentCard() {
        guard let layout = generatedLayout else { return }
        var card = SavedFlashcard(layout: layout)
        card.customGlossaryNotes = currentGlossaryNotes // Append current notes
        card.flipCount = currentFlipCount
        card.hasOpenedGlossary = currentHasOpenedGlossary
        card.isFullyGrown = currentIsFullyGrown
        savedDeck.insert(card, at: 0)
        saveToDisk()
    }
    
    func deleteCard(at offsets: IndexSet) {
        savedDeck.remove(atOffsets: offsets)
        saveToDisk()
    }
    
    func deleteCard(withId id: UUID) {
        savedDeck.removeAll { $0.id == id }
        saveToDisk()
    }
    
    func updateGlossaryNotes(for id: UUID, notes: [GlossaryNote]) {
        if let index = savedDeck.firstIndex(where: { $0.id == id }) {
            savedDeck[index].customGlossaryNotes = notes
            saveToDisk()
        }
    }
    
    // Update persistent learning stats
    func updateCardStats(for id: UUID, flipCount: Int, hasOpenedGlossary: Bool, isFullyGrown: Bool) {
        if let index = savedDeck.firstIndex(where: { $0.id == id }) {
            savedDeck[index].flipCount = flipCount
            savedDeck[index].hasOpenedGlossary = hasOpenedGlossary
            if isFullyGrown {
                savedDeck[index].isFullyGrown = true // Lock at 100% permanently
            }
            saveToDisk()
        }
    }
    
    private func saveToDisk() {
        do {
            let data = try JSONEncoder().encode(savedDeck)
            let url = getDocumentsDirectory().appendingPathComponent("MyDeck.json")
            try data.write(to: url)
        } catch {
            print("Failed to save deck: \(error.localizedDescription)")
        }
    }
    
    private func loadFromDisk() {
        let url = getDocumentsDirectory().appendingPathComponent("MyDeck.json")
        guard let data = try? Data(contentsOf: url) else { return }
        if let decoded = try? JSONDecoder().decode([SavedFlashcard].self, from: data) {
            self.savedDeck = decoded
        }
    }
    
    private func getDocumentsDirectory() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
    
    // MARK: - Private Helpers
    private func performOCR(on image: UIImage) async throws -> String {
        guard let cgImage = image.cgImage else { throw URLError(.badURL) }
        return try await withCheckedThrowingContinuation { continuation in
            let request = VNRecognizeTextRequest { request, error in
                if let error = error {
                    continuation.resume(throwing: error)
                    return
                }
                let observations = request.results as? [VNRecognizedTextObservation] ?? []
                let fullText = observations.compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")
                continuation.resume(returning: fullText)
            }
            request.recognitionLevel = .accurate
            request.usesLanguageCorrection = true
            let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
            try? handler.perform([request])
        }
    }
    
    private func generateBlueprint(from text: String) async throws -> Layout {
        let prompt = "Summarize these notes into a study flashcard:\n\n\(text)"
        let response = try await modelSession.respond(to: prompt, generating: Layout.self)
        return response.content
    }
}
