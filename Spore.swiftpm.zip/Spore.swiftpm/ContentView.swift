import SwiftUI
import PhotosUI

struct ContentView: View {
    @State private var brain = Brain()
    
    // UI State
    @State private var showManualInput = false
    @State private var manualInputText = ""
    @State private var selectedPhotoItem: PhotosPickerItem? = nil
    @State private var showLibrary = false
    @State private var isCardSaved = false
    
    // Animation States
    @State private var showSplash = true
    @State private var isResetting = false
    
    var body: some View {
        ZStack {
            // 1. The Main App Interface
            NavigationStack {
                ZStack {
                    AmbientBackground(theme: brain.generatedLayout?.suggestedTheme)
                    
                    VStack {
                        if brain.isProcessing {
                            ProcessingView()
                                .transition(.opacity.combined(with: .scale(scale: 0.9)))
                        } else if let layout = brain.generatedLayout {
                            ResultView(
                                layout: layout,
                                isCardSaved: $isCardSaved,
                                onSave: {
                                    UIImpactFeedbackGenerator(style: .soft).impactOccurred()
                                    brain.saveCurrentCard()
                                    withAnimation { isCardSaved = true }
                                },
                                onStartOver: {
                                    // Trigger the custom sweep animation
                                    withAnimation {
                                        isResetting = true
                                    }
                                },
                                onNotesChanged: { newNotes in
                                    // Keep the brain up to date BEFORE the card is officially saved
                                    brain.currentGlossaryNotes = newNotes
                                },
                                onStatsChanged: { flips, opened, fullyGrown in
                                    // Keep stats up to date BEFORE the card is officially saved
                                    brain.currentFlipCount = flips
                                    brain.currentHasOpenedGlossary = opened
                                    brain.currentIsFullyGrown = fullyGrown
                                }
                            )
                            .transition(.move(edge: .bottom).combined(with: .opacity))
                        } else {
                            HomeView(
                                selectedPhotoItem: $selectedPhotoItem,
                                showManualInput: $showManualInput
                            )
                            .transition(.opacity.combined(with: .move(edge: .bottom)))
                        }
                    }
                    .animation(.spring(response: 0.6, dampingFraction: 0.8), value: brain.isProcessing)
                    .animation(.spring(response: 0.6, dampingFraction: 0.8), value: brain.generatedLayout != nil)
                }
                .sheet(isPresented: $showManualInput) {
                    ManualInputSheet(text: $manualInputText) {
                        Task {
                            showManualInput = false
                            await brain.process(manualInputText)
                        }
                    }
                }
                .sheet(isPresented: $showLibrary) {
                    LibrarySheet(brain: brain, showLibrary: $showLibrary)
                }
                .onChange(of: selectedPhotoItem) { _, newItem in
                    Task {
                        if let data = try? await newItem?.loadTransferable(type: Data.self),
                           let image = UIImage(data: data) {
                            await brain.process(image)
                            selectedPhotoItem = nil
                        }
                    }
                }
                .onChange(of: brain.generatedLayout != nil) { _, hasLayout in
                    if hasLayout { isCardSaved = false }
                }
                .toolbar {
                    if brain.generatedLayout == nil && !brain.isProcessing && !showSplash  {
                        ToolbarItem(placement: .topBarLeading) {
                            Button(action: { showLibrary = true }) {
                                Label("My Deck", systemImage: "square.stack.3d.up.fill")
                                    .foregroundStyle(.primary)
                            }
                        }
                    }
                }
            }
            
            // 2. Start Over Sweep Animation
            if isResetting {
                ResetTransitionView(
                    onMidpoint: {
                        // Switch back to home state while screen is green
                        brain.generatedLayout = nil
                        isCardSaved = false
                    },
                    onEnd: {
                        isResetting = false
                    }
                )
                .zIndex(150)
            }
            
            // 3. Full-Screen Splash Overlay
            if showSplash {
                SplashAnimationView {
                    withAnimation(.easeInOut(duration: 0.6)) {
                        showSplash = false
                    }
                }
                .transition(.opacity)
                .zIndex(200)
            }
        }
    }
}

#Preview {
    ContentView()
}
