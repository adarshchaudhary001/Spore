import Foundation
import FoundationModels

// MARK: - Enums
// Intent controls the STRUCTURE (Layout) of the card
@Generable
enum Intent: String, Codable, CaseIterable, Sendable {
    case conceptDefinition   // Explaining a single term
    case processFlow         // Steps in a process (Algorithms, Cycles)
    case historicalTimeline  // Dates and events
    case comparison          // A vs B
}

// Theme controls the AESTHETIC (Subject) of the card
@Generable
enum VisualTheme: String, Codable, CaseIterable, Sendable {
    case technology      // Computer Science, Math, Physics, Engineering
    case nature          // Biology, Chemistry, Environmental Science
    case humanities      // History, Literature, Philosophy, Sociology
    case business        // Economics, Finance, Marketing, Law
    case creative        // Music, Art, Design, Architecture, Theater
    case standard        // General Business, Law, or Unspecified
}

// MARK: - Glossary Struct
@Generable
struct Keyword: Codable, Sendable, Identifiable, Hashable {
    var id: String { term }
    let term: String
    let definition: String
}

// note struct to keep text field focus stable during editing
struct GlossaryNote: Identifiable, Codable, Hashable, Sendable {
    var id = UUID()
    var text: String
}

// MARK: - Main Layout Struct
@Generable
struct Layout: Codable, Sendable {
    let topicTitle: String
    let intent: Intent
    let suggestedTheme: VisualTheme
    let keyPoints: [String]      // Bullet points
    let mnemonics: String        // Memory aid

    let keywords: [Keyword]?
}

// MARK: - Persistence Wrapper
struct SavedFlashcard: Identifiable, Codable {
    let id: UUID
    let dateCreated: Date
    let layout: Layout
    var customGlossaryNotes: [GlossaryNote]?
    
    // Learning Progress Stats
    var flipCount: Int?
    var hasOpenedGlossary: Bool?
    var isFullyGrown: Bool? // Locks progress at 100%
    
    init(layout: Layout) {
        self.id = UUID()
        self.dateCreated = Date()
        self.layout = layout
    }
}
