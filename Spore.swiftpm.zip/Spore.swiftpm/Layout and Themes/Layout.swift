import SwiftUI

// MARK: - Highlight Helper
/// Converts text into an AttributedString, making any glossary keywords clickable
func highlightText(_ text: String, theme: VisualTheme, keywords: [Keyword]?) -> AttributedString {
    var attrStr = AttributedString(text)
    guard let keywords = keywords, !keywords.isEmpty else { return attrStr }
    
    // Sort keywords by length descending so multi-word phrases get matched first
    let sortedTerms = keywords.map { $0.term }.sorted { $0.count > $1.count }
    
    for term in sortedTerms {
        // Use regex boundary \b to match whole words safely, ignoring case
        let escapedTerm = NSRegularExpression.escapedPattern(for: term)
        let pattern = "\\b\(escapedTerm)\\b"
        
        var searchRange = attrStr.startIndex..<attrStr.endIndex
        while let range = attrStr[searchRange].range(of: pattern, options: [.regularExpression, .caseInsensitive]) {
            // Turn the keyword into a link with a custom spore
            attrStr[range].link = URL(string: "spore://glossary")
            attrStr[range].underlineStyle = .single
            searchRange = range.upperBound..<attrStr.endIndex
        }
    }
    return attrStr
}

struct DefinitionLayout: View {
    let items: [String]
    let theme: VisualTheme
    let keywords: [Keyword]?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            ForEach(items, id: \.self) { item in
                HStack(alignment: .firstTextBaseline, spacing: 12) {
                    Circle().fill(theme.accentColor).frame(width: 6, height: 6).padding(.top, 8)
                    Text(highlightText(item, theme: theme, keywords: keywords))
                        .font(.system(.body, design: theme.fontDesign))
                        .foregroundStyle(theme.textColor)
                        .lineSpacing(4)
                }
            }
        }
    }
}

struct ProcessFlowLayout: View {
    let items: [String]
    let theme: VisualTheme
    let keywords: [Keyword]?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ForEach(Array(items.enumerated()), id: \.offset) { index, item in
                HStack(alignment: .top, spacing: 16) {
                    VStack(spacing: 0) {
                        ZStack {
                            Circle().fill(theme.accentColor).frame(width: 24, height: 24)
                            Text("\(index + 1)").font(.caption.bold()).foregroundStyle(theme == .technology ? .black : .white)
                        }
                        if index != items.count - 1 {
                            Rectangle().fill(theme.accentColor.opacity(0.3)).frame(width: 2).frame(minHeight: 30)
                        }
                    }
                    Text(highlightText(item, theme: theme, keywords: keywords))
                        .font(.system(.body, design: theme.fontDesign))
                        .foregroundStyle(theme.textColor)
                        .padding(.bottom, 16)
                }
            }
        }
    }
}

struct ComparisonLayout: View {
    let items: [String]
    let theme: VisualTheme
    let keywords: [Keyword]?
    
    var body: some View {
        VStack(spacing: 12) {
            ForEach(items, id: \.self) { item in
                HStack {
                    Rectangle().fill(theme.accentColor).frame(width: 4)
                    Text(highlightText(item, theme: theme, keywords: keywords))
                        .font(.system(.subheadline, design: theme.fontDesign))
                        .foregroundStyle(theme.textColor)
                        .padding(.leading, 8)
                    Spacer()
                }
                .padding(12).background(theme.textColor.opacity(0.05)).cornerRadius(8)
            }
        }
    }
}

struct TimelineLayout: View {
    let items: [String]
    let theme: VisualTheme
    let keywords: [Keyword]?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            ForEach(items, id: \.self) { item in
                HStack(alignment: .top) {
                    Image(systemName: "clock.arrow.circlepath").font(.caption).foregroundStyle(theme.accentColor).padding(.top, 4)
                    Text(highlightText(item, theme: theme, keywords: keywords))
                        .font(.system(.body, design: theme.fontDesign))
                        .foregroundStyle(theme.textColor)
                }
                Divider().opacity(0.3)
            }
        }
    }
}
