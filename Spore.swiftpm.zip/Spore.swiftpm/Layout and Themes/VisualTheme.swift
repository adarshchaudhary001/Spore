import SwiftUI

extension VisualTheme {
    @ViewBuilder
    var backgroundView: some View {
        switch self {
        case .technology:
            // Dark Terminal / Blueprint look for CS & Math
            ZStack {
                Color(red: 0.1, green: 0.12, blue: 0.15)
                // Grid Pattern
                GeometryReader { geo in
                    Path { path in
                        let step: CGFloat = 20
                        for x in stride(from: 0, to: geo.size.width, by: step) {
                            path.move(to: CGPoint(x: x, y: 0))
                            path.addLine(to: CGPoint(x: x, y: geo.size.height))
                        }
                        for y in stride(from: 0, to: geo.size.height, by: step) {
                            path.move(to: CGPoint(x: 0, y: y))
                            path.addLine(to: CGPoint(x: geo.size.width, y: y))
                        }
                    }
                    .stroke(Color.green.opacity(0.1), lineWidth: 1)
                }
            }
            
        case .nature:
            // Organic, soft look for Biology & Chem
            LinearGradient(colors: [Color(red: 0.95, green: 1.0, blue: 0.96), .white], startPoint: .topLeading, endPoint: .bottomTrailing)
            .overlay(
                // blobs
                GeometryReader { geo in
                    Circle()
                        .fill(Color.green.opacity(0.05))
                        .frame(width: 300)
                        .offset(x: -100, y: -50)
                }
            )
            
        case .humanities:
            // Warm Paper / Classic look for History & Arts
            Color(red: 0.98, green: 0.96, blue: 0.93)

                
        case .business:
            // professional corporate look
            LinearGradient(colors: [Color(red: 0.92, green: 0.94, blue: 0.96), .white], startPoint: .topLeading, endPoint: .bottomTrailing)
            .overlay(
                // geometric watermark
                GeometryReader { geo in
                    Path { path in
                        path.move(to: CGPoint(x: geo.size.width * 0.7, y: 0))
                        path.addLine(to: CGPoint(x: geo.size.width, y: geo.size.height * 0.4))
                        path.addLine(to: CGPoint(x: geo.size.width, y: 0))
                    }
                    .fill(Color.blue.opacity(0.05))
                }
            )
            
        case .creative:
            // Vibrant look for arts and design
            LinearGradient(colors: [Color(red: 1.0, green: 0.95, blue: 0.95), Color(red: 0.95, green: 0.95, blue: 1.0)], startPoint: .topLeading, endPoint: .bottomTrailing)
            .overlay(
                // blobs
                GeometryReader { geo in
                    ZStack {
                        Circle()
                            .fill(Color.purple.opacity(0.08))
                            .frame(width: 250)
                            .offset(x: geo.size.width * 0.4, y: -50)
                        Circle()
                            .fill(Color.pink.opacity(0.08))
                            .frame(width: 200)
                            .offset(x: -50, y: geo.size.height * 0.6)
                    }
                }
            )
            
        case .standard:
            LinearGradient(colors: [Color(red: 0.96, green: 0.98, blue: 1.0), .white], startPoint: .topLeading, endPoint: .bottomTrailing)
        }
    }
    
    var textColor: Color {
        switch self {
        case .technology: return .green.opacity(0.9)
        case .humanities: return .black.opacity(0.85)
        case .business: return Color(red: 0.1, green: 0.15, blue: 0.25)
        case .creative: return Color(red: 0.3, green: 0.1, blue: 0.3) 
        default: return .black.opacity(0.9)
        }
    }
    
    var accentColor: Color {
        switch self {
        case .technology: return Color.green
        case .nature: return Color(red: 0.2, green: 0.6, blue: 0.3) // Green
        case .humanities: return Color(red: 0.6, green: 0.3, blue: 0.2) // Brown
        case .business: return Color(red: 0.15, green: 0.35, blue: 0.65) // Blue
        case .creative: return Color(red: 0.8, green: 0.3, blue: 0.5) // Pinkish-Purple
        case .standard: return Color.blue
        }
    }
    
    var fontDesign: Font.Design {
        switch self {
        case .technology: return .monospaced
        case .nature: return .rounded
        case .humanities: return .serif
        case .creative: return .rounded
        case .business, .standard: return .default
        }
    }
    
    // Full screen app background
    @ViewBuilder
    var mainBackground: some View {
        switch self {
        case .technology:
            ZStack {
                Color(red: 0.05, green: 0.07, blue: 0.1).ignoresSafeArea()
                RadialGradient(colors: [Color.green.opacity(0.1), .clear], center: .topTrailing, startRadius: 0, endRadius: 600)
                RadialGradient(colors: [Color.blue.opacity(0.05), .clear], center: .bottomLeading, startRadius: 0, endRadius: 600)
            }
        case .nature:
            ZStack {
                Color(red: 0.94, green: 0.98, blue: 0.94).ignoresSafeArea()
                RadialGradient(colors: [Color.green.opacity(0.15), .clear], center: .topLeading, startRadius: 0, endRadius: 500)
                RadialGradient(colors: [Color.yellow.opacity(0.1), .clear], center: .bottomTrailing, startRadius: 0, endRadius: 500)
            }
        case .humanities:
            ZStack {
                Color(red: 0.96, green: 0.94, blue: 0.90).ignoresSafeArea()
                RadialGradient(colors: [Color.orange.opacity(0.08), .clear], center: .center, startRadius: 0, endRadius: 700)
            }
        case .business:
            ZStack {
                Color(red: 0.95, green: 0.96, blue: 0.98).ignoresSafeArea()
                RadialGradient(colors: [Color.blue.opacity(0.08), .clear], center: .topLeading, startRadius: 0, endRadius: 600)
            }
        case .creative:
            ZStack {
                Color(red: 0.98, green: 0.96, blue: 0.99).ignoresSafeArea()
                RadialGradient(colors: [Color.pink.opacity(0.12), .clear], center: .topLeading, startRadius: 0, endRadius: 500)
                RadialGradient(colors: [Color.purple.opacity(0.12), .clear], center: .bottomTrailing, startRadius: 0, endRadius: 500)
            }
        case .standard:
            ZStack {
                Color(uiColor: .systemGroupedBackground).ignoresSafeArea()
                GeometryReader { proxy in
                    ZStack {
                        Circle().fill(Color.blue.opacity(0.1)).frame(width: proxy.size.width * 0.8)
                            .offset(x: -proxy.size.width * 0.2, y: -proxy.size.height * 0.3).blur(radius: 60)
                        Circle().fill(Color.teal.opacity(0.1)).frame(width: proxy.size.width * 0.8)
                            .offset(x: proxy.size.width * 0.2, y: proxy.size.height * 0.2).blur(radius: 60)
                    }
                }
            }
        }
    }
}
