import SwiftUI

// MARK: - 1. Processing Animation
/// A green circle that expands from the center to fill the screen during processing.
struct ExpansionLoaderView: View {
    @State private var isPulsing = false
    @State private var circleScale: CGFloat = 0.01
    @State private var opacity: Double = 0

    var body: some View {
        ZStack {
            Circle()
                .fill(LinearGradient(colors: [.green, .teal], startPoint: .topLeading, endPoint: .bottomTrailing))
                .scaleEffect(circleScale * (isPulsing ? 1.03 : 1.0))
                .opacity(0.95)

            VStack(spacing: 24) {
                Image(systemName: "leaf.fill")
                    .font(.system(size: 80))
                    .foregroundStyle(.white)
                    .shadow(color: .black.opacity(0.1), radius: 10)
                    .scaleEffect(isPulsing ? 1.08 : 0.92)

                VStack(spacing: 8) {
                    Text("Extracting Information...")
                        .font(.system(size: 24, weight: .bold, design: .rounded))
                    Text("Turning your notes into knowledge")
                        .font(.subheadline)
                        .opacity(0.9)
                }
                .foregroundStyle(.white)
                .shimmering()
            }
            .opacity(opacity)
        }
        .ignoresSafeArea()
        .task {
            // Expand circle
            withAnimation(.spring(response: 0.7, dampingFraction: 0.85)) {
                circleScale = 3
            }

            try? await Task.sleep(nanoseconds: 50_000_000)

            withAnimation(.easeIn(duration: 0.5)) {
                opacity = 1
            }

            // pulsing loop
            while !Task.isCancelled {
                withAnimation(.easeInOut(duration: 1.2)) {
                    isPulsing.toggle()
                }
                try? await Task.sleep(nanoseconds: 1_200_000_000)
            }
        }
    }
}

// MARK: - 2. Reset Transition View
///Handles the animation that plays when start over button is tapped
struct ResetTransitionView: View {
    @State private var phase: Int = 0 // 0 = small, 1 = expanded, 2 = shrink
    var onMidpoint: () -> Void
    var onEnd: () -> Void

    var body: some View {
        GeometryReader { geo in
            let maxDimension = max(geo.size.width, geo.size.height)

            Circle()
                .fill(LinearGradient(colors: [.green, .teal], startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: 70, height: 70)
                .scaleEffect(phase == 0 ? 0.01 : (phase == 1 ? maxDimension / 20 : 0.01))
                .position(
                    x: phase < 2 ? 40 : geo.size.width * 0.5,
                    y: phase < 2 ? geo.size.height - 40 : geo.size.height * 0.25
                )
                .ignoresSafeArea()
        }
        .ignoresSafeArea()
        .task {
            // Expand from bottom-left
            withAnimation(.spring(response: 0.7, dampingFraction: 0.85)) {
                phase = 1
            }

            try? await Task.sleep(nanoseconds: 350_000_000)
            onMidpoint()

            // Shrink toward upper-center
            withAnimation(.spring(response: 0.7, dampingFraction: 0.85)) {
                phase = 2
            }

            try? await Task.sleep(nanoseconds: 900_000_000)
            onEnd()
        }
    }
}


// MARK: - 3. Save Burst Animation
struct SaveSuccessBurst: View {
    let count: Int = 12
    @State private var isBursting = false
    
    var body: some View {
        ZStack {
            ForEach(0..<count, id: \.self) { index in
                Circle()
                    .fill(Color.yellow)
                    .frame(width: 8, height: 8)
                    .modifier(ParticleModifier(index: index, count: count, isBursting: isBursting))
            }
        }
        .onAppear {
            withAnimation(.spring(response: 0.8, dampingFraction: 0.9)) {
                isBursting = true
            }
        }
    }
}

struct ParticleModifier: ViewModifier {
    let index: Int; let count: Int; let isBursting: Bool
    func body(content: Content) -> some View {
        let angle = Double(index) / Double(count) * 2 * .pi
        let xOffset = isBursting ? CGFloat(cos(angle) * 80) : 0
        let yOffset = isBursting ? CGFloat(sin(angle) * 80) : 0
        return content.scaleEffect(isBursting ? 0 : 1).offset(x: xOffset, y: yOffset).opacity(isBursting ? 0 : 1)
    }
}

// MARK: - 4. Shimmer Effect for text
struct ShimmerEffect: ViewModifier {
    @State private var phase: CGFloat = 0
    func body(content: Content) -> some View {
        content.overlay(
            GeometryReader { geo in
                Rectangle()
                    .fill(LinearGradient(gradient: Gradient(colors: [.gray.opacity(0.6), .white.opacity(0.5), .gray.opacity(0.5)]), startPoint: .topLeading, endPoint: .bottomTrailing))
                    .rotationEffect(.degrees(30))
                    .offset(x: -geo.size.width + (geo.size.width * 3 * phase))
            }
        ).mask(content).onAppear { withAnimation(.linear(duration: 2.5).repeatForever(autoreverses: false)) { phase = 1 } }
    }
}

extension View { func shimmering() -> some View { modifier(ShimmerEffect()) } }

// MARK: - 5. Launch Animation
///This animation will play when teh app is launched for the first time
struct SplashAnimationView: View {
    @State private var phase = 0
    var onFinish: () -> Void

    var body: some View {
        ZStack {
            Color(uiColor: .systemBackground)
                .ignoresSafeArea()

            Circle()
                .fill(LinearGradient(colors: [.green, .teal], startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: 84, height: 84)
                .scaleEffect(phase == 0 ? 45 : 1.0)
                .offset(y: phase == 2 ? -40 : 0)

            Image(systemName: "leaf.fill")
                .font(.system(size: 44))
                .foregroundStyle(.white)
                .offset(y: phase == 2 ? -40 : 0)

            Text("Spore")
                .font(.system(size: 48, weight: .black, design: .rounded))
                .foregroundStyle(.primary)
                .opacity(phase == 2 ? 1 : 0)
                .offset(y: phase == 2 ? 30 : 50)
        }
        .task {
            // Phase 1: Collapse circle
            withAnimation(.spring(response: 0.8, dampingFraction: 0.85).delay(0.2)) {
                phase = 1
            }

            try? await Task.sleep(nanoseconds: 1_200_000_000)

            // Phase 2: Reveal the name
            withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
                phase = 2
            }

            try? await Task.sleep(nanoseconds: 1_000_000_000)

            onFinish()
        }
    }
}


#Preview {

}
