import SwiftUI

// MARK: - Row View
struct FlashCardRowView: View {
    let layout: Layout
    let date: Date
    let isFullyGrown: Bool
    
    private var intentIcon: String {
        switch layout.intent {
        case .conceptDefinition: return "text.book.closed.fill"
        case .processFlow: return "arrow.triangle.2.circlepath"
        case .historicalTimeline: return "clock.fill"
        case .comparison: return "scale.3d"
        }
    }
    
    var body: some View {
        HStack(spacing: 16) {
            ZStack {
                if isFullyGrown {
                    // Special thumbnail if fully learned
                    LinearGradient(colors: [.yellow, .green], startPoint: .topLeading, endPoint: .bottomTrailing)
                    Image(systemName: "sparkles")
                        .font(.caption)
                        .foregroundStyle(.white)
                        .padding(6)
                        .background(Circle().fill(Color.white.opacity(0.3)))
                } else {
                    layout.suggestedTheme.backgroundView
                    Image(systemName: intentIcon)
                        .font(.caption)
                        .foregroundStyle(layout.suggestedTheme.accentColor)
                        .padding(6)
                        .background(Circle().fill(Color.white.opacity(0.5)))
                }
            }
            .frame(width: 50, height: 70)
            .clipShape(RoundedRectangle(cornerRadius: 8))
            .shadow(color: isFullyGrown ? .orange.opacity(0.4) : .black.opacity(0.1), radius: isFullyGrown ? 4 : 2)
            .overlay {
                if isFullyGrown {
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color.yellow.opacity(0.8), lineWidth: 1.5)
                }
            }
            
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    Text(layout.topicTitle).font(.headline).lineLimit(1)
                    if isFullyGrown {
                        Image(systemName: "star.fill")
                            .font(.system(size: 10))
                            .foregroundStyle(.yellow)
                    }
                }
                HStack {
                    Text(date.formatted(date: .abbreviated, time: .omitted)).font(.caption).foregroundStyle(.secondary)
                    
                    if isFullyGrown {
                        Text("100%").font(.system(size: 10, weight: .bold)).foregroundStyle(.green)
                    }
                }
            }
        }
    }
}

// MARK: - Library Sheet
struct LibrarySheet: View {
    var brain: Brain
    @Binding var showLibrary: Bool
    
    @State private var selectedTheme: VisualTheme? = nil
    
    var filteredDeck: [SavedFlashcard] {
        if let theme = selectedTheme {
            return brain.savedDeck.filter { $0.layout.suggestedTheme == theme }
        }
        return brain.savedDeck
    }
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                if !brain.savedDeck.isEmpty {
                    filterBar
                    Divider()
                }
                deckList
            }
            .navigationTitle("My Deck")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { showLibrary = false }
                }
            }
        }
    }
    
    // Subviews to improve compilation time
    @ViewBuilder
    private var filterBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                FilterChip(title: "All", isSelected: selectedTheme == nil) {
                    withAnimation { selectedTheme = nil }
                }
                
                ForEach(VisualTheme.allCases, id: \.self) { theme in
                    FilterChip(title: theme.rawValue.capitalized, isSelected: selectedTheme == theme) {
                        withAnimation { selectedTheme = theme }
                    }
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 12)
        }
        .background(Color(uiColor: .systemBackground))
    }
    
    @ViewBuilder
    private var deckList: some View {
        List {
            if filteredDeck.isEmpty {
                ContentUnavailableView(
                    selectedTheme == nil ? "No Cards" : "No \(selectedTheme!.rawValue.capitalized) Cards",
                    systemImage: "square.stack.3d.up.slash"
                )
            } else {
                ForEach(filteredDeck) { card in
                    NavigationLink(destination: ZStack {
                        // put card's theme into the background
                        AmbientBackground(theme: card.layout.suggestedTheme)
                            .ignoresSafeArea()
                        
                        FlashCardGeneratorView(
                            layout: card.layout,
                            cardId: card.id,
                            initialNotes: card.customGlossaryNotes ?? [],
                            initialFlipCount: card.flipCount ?? 0,
                            initialHasOpenedGlossary: card.hasOpenedGlossary ?? false,
                            initialIsFullyGrown: card.isFullyGrown ?? false,
                            onNotesChanged: { newNotes in
                                brain.updateGlossaryNotes(for: card.id, notes: newNotes)
                            },
                            onStatsChanged: { flips, opened, fullyGrown in
                                brain.updateCardStats(for: card.id, flipCount: flips, hasOpenedGlossary: opened, isFullyGrown: fullyGrown)
                            }
                        )
                    }) {
                        FlashCardRowView(
                            layout: card.layout,
                            date: card.dateCreated,
                            isFullyGrown: card.isFullyGrown ?? false
                        )
                    }
                }
                .onDelete { indexSet in
                    for index in indexSet {
                        let cardToDelete = filteredDeck[index]
                        brain.deleteCard(withId: cardToDelete.id)
                    }
                }
            }
        }
        .listStyle(.plain)
    }
}

struct FilterChip: View {
    let title: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.subheadline.weight(isSelected ? .bold : .medium))
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
                .background(isSelected ? Color.blue : Color(uiColor: .secondarySystemBackground))
                .foregroundStyle(isSelected ? .white : .primary)
                .clipShape(Capsule())
                .animation(.easeInOut, value: isSelected)
        }
    }
}

// MARK: - Glossary Sheet
struct GlossarySheet: View {
    let keywords: [Keyword]
    let theme: VisualTheme
    
    @State var customNotes: [GlossaryNote]
    var onNotesChanged: (([GlossaryNote]) -> Void)? = nil
    
    @State private var newNoteText: String = ""
    @Environment(\.dismiss) var dismiss
    
    init(keywords: [Keyword], theme: VisualTheme, initialNotes: [GlossaryNote], onNotesChanged: (([GlossaryNote]) -> Void)? = nil) {
        self.keywords = keywords
        self.theme = theme
        self._customNotes = State(initialValue: initialNotes)
        self.onNotesChanged = onNotesChanged
    }
    
    var body: some View {
        NavigationStack {
            ZStack {
                // put card's visual theme into the background
                theme.backgroundView
                    .ignoresSafeArea()
                
                List {
                    Section {
                        ForEach(keywords) { keyword in
                            VStack(alignment: .leading, spacing: 6) {
                                Text(keyword.term)
                                    .font(.system(.headline, design: theme.fontDesign))
                                    .foregroundStyle(theme.accentColor)
                                
                                Text(keyword.definition)
                                    .font(.system(.subheadline, design: theme.fontDesign))
                                    .foregroundStyle(theme.textColor)
                                    .opacity(0.8)
                            }
                            .padding(.vertical, 4)
                            .listRowBackground(theme.textColor.opacity(0.05))
                        }
                    } header: {
                        Text("Keywords")
                            .font(.system(.caption, design: theme.fontDesign, weight: .bold))
                            .foregroundStyle(theme.accentColor)
                    }
                    
                    Section {
                        ForEach($customNotes) { $note in
                            TextField("Note", text: $note.text, axis: .vertical)
                                .font(.system(.body, design: theme.fontDesign))
                                .foregroundStyle(theme.textColor)
                                .onChange(of: note.text) { _, _ in
                                    onNotesChanged?(customNotes)
                                }
                                .listRowBackground(theme.textColor.opacity(0.05))
                        }
                        .onDelete { indices in
                            customNotes.remove(atOffsets: indices)
                            onNotesChanged?(customNotes)
                        }
                        
                        HStack {
                            TextField("Add a new note...", text: $newNoteText)
                                .font(.system(.body, design: theme.fontDesign))
                                .foregroundStyle(theme.textColor)
                                .onSubmit {
                                    addNote()
                                }
                            
                            Button(action: addNote) {
                                Image(systemName: "plus.circle.fill")
                                    .foregroundStyle(newNoteText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? .gray : theme.accentColor)
                                    .font(.title3)
                            }
                            .disabled(newNoteText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                        }
                        .listRowBackground(theme.textColor.opacity(0.05))
                    } header: {
                        Text("My Notes")
                            .font(.system(.caption, design: theme.fontDesign, weight: .bold))
                            .foregroundStyle(theme.accentColor)
                    }
                }
                .scrollContentBackground(.hidden) // Make List transparent to show theme background
            }
            .navigationTitle("Glossary")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                        .font(.system(.headline, design: theme.fontDesign))
                        .foregroundStyle(theme.accentColor)
                }
            }
        }
        .presentationDetents([.medium, .large])
    }
    
    private func addNote() {
        let trimmed = newNoteText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        customNotes.append(GlossaryNote(text: trimmed))
        newNoteText = ""
        onNotesChanged?(customNotes)
    }
}


