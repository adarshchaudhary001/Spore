import SwiftUI

// MARK: - Main Interactive Card
struct FlashCardGeneratorView: View {
    let layout: Layout
    var cardId: UUID? = nil
    
    var initialNotes: [GlossaryNote] = []
    var initialFlipCount: Int = 0
    var initialHasOpenedGlossary: Bool = false
    var initialIsFullyGrown: Bool = false
    
    var onNotesChanged: (([GlossaryNote]) -> Void)? = nil
    var onStatsChanged: ((Int, Bool, Bool) -> Void)? = nil // (flipCount, hasOpened, isFullyGrown)
    
    @State private var isFlipped = false
    @State private var baseRotation: Double = 0
    @State private var dragOffset: Double = 0
    
    // Controls the Glossary Sheet
    @State private var showGlossary = false
    
    // Progress Tracking
    @State private var flipCount = 0
    @State private var hasOpenedGlossary = false
    @State private var localNotesCount = 0
    @State private var conceptStrength: Double = 0.0
    @State private var isFullyGrownLocal = false
    
    
    var strengthText: String {
        if isFullyGrownLocal { return "Fully Grown" }
        if conceptStrength < 30 { return "Sprouting" }
        if conceptStrength < 70 { return "Growing" }
        return "Blooming"
    }
    
    var body: some View {
        ZStack {
            Color.clear
            
            VStack(spacing: 24) {
                // Progress Badge
                HStack(spacing: 12) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Concept Strength").font(.system(size: 10, weight: .bold, design: .rounded)).textCase(.uppercase).foregroundStyle(.secondary)
                        HStack(alignment: .firstTextBaseline, spacing: 6) {
                            Text(strengthText).font(.system(size: 16, weight: .bold, design: .rounded))
                            Text("\(Int(conceptStrength))%").font(.caption.bold()).foregroundStyle(isFullyGrownLocal ? .green : layout.suggestedTheme.accentColor)
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 10)
                .background(.ultraThinMaterial)
                .clipShape(Capsule())
                .shadow(color: isFullyGrownLocal ? .green.opacity(0.15) : .black.opacity(0.08), radius: 10, y: 4)
                
                ZStack {
                    // Background
                    RoundedRectangle(cornerRadius: 34, style: .continuous)
                        .stroke(layout.suggestedTheme.accentColor.opacity(0.15), lineWidth: 4)
                        .frame(maxWidth: 380, maxHeight: 570)
                    
                    // Progress Ring
                    RoundedRectangle(cornerRadius: 34, style: .continuous)
                        .trim(from: 0, to: CGFloat(conceptStrength) / 100.0)
                        .stroke(isFullyGrownLocal ? Color.green : layout.suggestedTheme.accentColor, style: StrokeStyle(lineWidth: 4, lineCap: .round))
                        .frame(maxWidth: 380, maxHeight: 570)
                        .animation(.spring(response: 1.0, dampingFraction: 0.8), value: conceptStrength)
                    
                    ZStack {
                        DetailedCardFace(layout: layout)
                            .rotation3DEffect(.degrees(180), axis: (x: 0, y: 1, z: 0))
                            .opacity(isFlipped ? 1 : 0)
                            .accessibilityHidden(!isFlipped)
                            // taps on the highlighted keywords
                            .environment(\.openURL, OpenURLAction { url in
                                if url.scheme == "spore" {
                                    showGlossary = true
                                    hasOpenedGlossary = true
                                    updateStrength()
                                    onStatsChanged?(flipCount, hasOpenedGlossary, isFullyGrownLocal)
                                    return .handled
                                }
                                return .systemAction
                            })
                        
                        SummaryCardFace(layout: layout)
                            .opacity(isFlipped ? 0 : 1)
                            .accessibilityHidden(isFlipped)
                    }
                    .frame(maxWidth: 360, maxHeight: 550)
                    .rotation3DEffect(.degrees(baseRotation + dragOffset), axis: (x: 0.0, y: 1.0, z: 0.0))
                    .onTapGesture { flipCard() }
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                // Follow finger continuously
                                dragOffset = Double(value.translation.width / 300) * 180
                                
                                // swap faces right as the card edge faces the user
                                let currentTotal = baseRotation + dragOffset
                                let normalized = abs(currentTotal.truncatingRemainder(dividingBy: 360))
                                let shouldBeFlipped = normalized >= 90 && normalized <= 270
                                
                                if isFlipped != shouldBeFlipped {
                                    isFlipped = shouldBeFlipped
                                }
                            }
                            .onEnded { value in
                                withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
                                    // Decide whether to complete the flip or snap back
                                    if value.translation.width > 50 {
                                        baseRotation += 180 // Swipe right
                                        flipCount += 1
                                    } else if value.translation.width < -50 {
                                        baseRotation -= 180 // Swipe left
                                        flipCount += 1
                                    }
                                    
                                    dragOffset = 0 // Reset drag on the card
                                    
                                    // Ensure the final face perfectly matches the settled rotation
                                    let finalNormalized = abs(baseRotation.truncatingRemainder(dividingBy: 360))
                                    isFlipped = (finalNormalized == 180)
                                }
                                updateStrength()
                                onStatsChanged?(flipCount, hasOpenedGlossary, isFullyGrownLocal)
                            }
                    )
                }
            }
        }
        .onAppear {
            flipCount = initialFlipCount
            hasOpenedGlossary = initialHasOpenedGlossary
            isFullyGrownLocal = initialIsFullyGrown
            localNotesCount = initialNotes.count
            withAnimation(.easeOut.delay(0.3)) {
                updateStrength()
            }
        }
        // Present the Glossary Sheet
        .sheet(isPresented: $showGlossary) {
            if let keywords = layout.keywords {
                GlossarySheet(
                    keywords: keywords,
                    theme: layout.suggestedTheme,
                    initialNotes: initialNotes,
                    onNotesChanged: { newNotes in
                        localNotesCount = newNotes.count
                        updateStrength()
                        onStatsChanged?(flipCount, hasOpenedGlossary, isFullyGrownLocal)
                        onNotesChanged?(newNotes)
                    }
                )
            }
        }
    }
    
    private func flipCard() {
        withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
            baseRotation += 180
            let finalNormalized = abs(baseRotation.truncatingRemainder(dividingBy: 360))
            isFlipped = (finalNormalized == 180)
            flipCount += 1
        }
        updateStrength()
        onStatsChanged?(flipCount, hasOpenedGlossary, isFullyGrownLocal)
    }
    
    private func updateStrength() {
        // Lock permanently at 100
        if isFullyGrownLocal {
            conceptStrength = 100
            return
        }
        
        let score = calculateStrengthScore()
        
        withAnimation(.spring(response: 0.7, dampingFraction: 0.8)) {
            conceptStrength = score
            
            if score >= 100 {
                isFullyGrownLocal = true
            }
        }
    }

    private func calculateStrengthScore() -> Double {
        var score: Double = 10 // Base understanding
        
        // Flip exploration (max 50 points)
        let flipPoints = min(flipCount, 5) * 10
        score += Double(flipPoints)
        
        // Glossary interaction
        if hasOpenedGlossary {
            score += 30
        }
        
        // Custom notes (10 points)
        let notesPoints = min(localNotesCount, 1) * 10
        score += Double(notesPoints)
        
        return min(score, 100)
    }
}

// MARK: - Card Faces
struct SummaryCardFace: View {
    let layout: Layout
    var body: some View {
        ZStack {
            layout.suggestedTheme.backgroundView
            VStack(spacing: 20) {
                Spacer()
                Text(layout.topicTitle).font(.system(size: 40, weight: .heavy, design: layout.suggestedTheme.fontDesign)).foregroundStyle(layout.suggestedTheme.textColor).multilineTextAlignment(.center).padding()
                if !layout.mnemonics.isEmpty {
                    VStack(spacing: 8) {
                        Image(systemName: "sparkles").foregroundStyle(.yellow)
                        Text(layout.mnemonics).font(.system(.title3, design: .serif)).italic().foregroundStyle(layout.suggestedTheme.textColor.opacity(0.8)).multilineTextAlignment(.center)
                    }.padding().background(RoundedRectangle(cornerRadius: 16).fill(Color.white.opacity(0.4))).padding(.horizontal, 30)
                }
                Spacer()
                HStack { Image(systemName: "hand.draw.fill"); Text("Tap to Flip") }.font(.caption).foregroundStyle(layout.suggestedTheme.textColor.opacity(0.4)).padding(.bottom, 30)
            }
        }.clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous)).shadow(color: .black.opacity(0.15), radius: 20, y: 10)
    }
}

struct DetailedCardFace: View {
    let layout: Layout
    @Environment(\.openURL) private var openURL
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .top) {
                VStack(alignment: .leading) {
                    Text("DETAILED NOTES").font(.system(size: 10, weight: .bold)).foregroundStyle(layout.suggestedTheme.accentColor)
                    Text(layout.topicTitle).font(.system(size: 22, weight: .bold, design: layout.suggestedTheme.fontDesign)).foregroundStyle(layout.suggestedTheme.textColor)
                }
                Spacer()
                Button(action: {
                    if let url = URL(string: "spore://glossary") {
                        openURL(url)
                    }
                }) {
                    HStack(spacing: 4) {
                        Image(systemName: "text.book.closed.fill")
                        Text("Glossary")
                            .font(.system(size: 12, weight: .bold))
                    }
                    .foregroundStyle(layout.suggestedTheme.accentColor)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(layout.suggestedTheme.accentColor.opacity(0.15))
                    .clipShape(Capsule())
                }
            }.padding(24).background(layout.suggestedTheme.accentColor.opacity(0.05))
            
            Divider().overlay(layout.suggestedTheme.accentColor.opacity(0.3))
            
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    switch layout.intent {
                    case .processFlow: ProcessFlowLayout(items: layout.keyPoints, theme: layout.suggestedTheme, keywords: layout.keywords)
                    case .comparison: ComparisonLayout(items: layout.keyPoints, theme: layout.suggestedTheme, keywords: layout.keywords)
                    case .historicalTimeline: TimelineLayout(items: layout.keyPoints, theme: layout.suggestedTheme, keywords: layout.keywords)
                    default: DefinitionLayout(items: layout.keyPoints, theme: layout.suggestedTheme, keywords: layout.keywords)
                    }
                }.padding(24)
            }
        }
        .background(layout.suggestedTheme.backgroundView)
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        .shadow(color: .black.opacity(0.15), radius: 20, y: 10)
        .tint(layout.suggestedTheme.accentColor)
    }
}
