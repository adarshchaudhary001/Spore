import SwiftUI
import PhotosUI

// MARK: - Home View
struct HomeView: View {
    @Binding var selectedPhotoItem: PhotosPickerItem?
    @Binding var showManualInput: Bool
    
    var body: some View {
        ZStack {
            VStack(spacing: 32) {
                Spacer()
                
                VStack(spacing: 24) {
                    // Central Green Logo
                    ZStack {
                        Circle()
                            .fill(LinearGradient(colors: [.green, .teal], startPoint: .topLeading, endPoint: .bottomTrailing))
                            .frame(width: 84, height: 84)
                            .shadow(color: .green.opacity(0.2), radius: 15, y: 10)
                        
                        Image(systemName: "leaf.fill")
                            .font(.system(size: 44))
                            .foregroundStyle(.white)
                    }
                    
                    VStack(spacing: 12) {
                        Text("Spore")
                            .font(.system(size: 48, weight: .black, design: .rounded))
                        
                        Text("Turn messy notes into\nsummarised Cards.")
                            .font(.body)
                            .multilineTextAlignment(.center)
                            .foregroundStyle(.secondary)
                    }
                }
                
                // Action Cards
                VStack(spacing: 16) {
                    PhotosPicker(selection: $selectedPhotoItem, matching: .images) {
                        HomeActionButton(title: "Scan Notes", subtitle: "Upload a photo", icon: "camera.viewfinder", color: .blue)
                    }
                    
                    Button(action: { showManualInput = true }) {
                        HomeActionButton(title: "Summarise Topic", subtitle: "Enter a topic to summarize", icon: "keyboard", color: .purple)
                    }
                }
                .padding(.horizontal, 24)
                
                Spacer()
                Spacer()
            }
        }
    }
}

struct ProcessingView: View {
    var body: some View {
        ExpansionLoaderView()
            .ignoresSafeArea()
            .transition(.asymmetric(
                insertion: .identity,
                removal: .scale(scale: 0.1).combined(with: .opacity) // Shrink back down
            ))
            .zIndex(50)
    }
}

struct ResultView: View {
    let layout: Layout
    @Binding var isCardSaved: Bool
    var onSave: () -> Void
    var onStartOver: () -> Void
    var onNotesChanged: (([GlossaryNote]) -> Void)? = nil
    var onStatsChanged: ((Int, Bool, Bool) -> Void)? = nil
    
    var body: some View {
        VStack {
            FlashCardGeneratorView(layout: layout, onNotesChanged: onNotesChanged, onStatsChanged: onStatsChanged)
                .padding(.top, 20)
            Spacer()
            HStack(spacing: 16) {
                Button(action: onStartOver) {
                    VStack { Image(systemName: "arrow.clockwise").font(.title2); Text("New").font(.caption2.bold()) }
                        .frame(width: 60, height: 60).background(.thinMaterial).clipShape(Circle())
                }
                Button(action: onSave) {
                    HStack(spacing: 12) {
                        Image(systemName: isCardSaved ? "checkmark" : "square.and.arrow.down.fill").font(.title3.bold())
                        Text(isCardSaved ? "Saved to Deck" : "Save Card").font(.headline)
                    }
                    .frame(maxWidth: .infinity).frame(height: 60)
                    .background(isCardSaved ? Color.green : Color.primary)
                    .foregroundStyle(isCardSaved ? .white : Color(uiColor: .systemBackground))
                    .clipShape(Capsule())
                }.disabled(isCardSaved)
                .overlay { if isCardSaved { SaveSuccessBurst().allowsHitTesting(false) } }
            }.padding(.horizontal, 24).padding(.bottom, 20)
        }
    }
}

struct AmbientBackground: View {
    var theme: VisualTheme?
    
    var body: some View {
        ZStack {
            if let theme {
                theme.mainBackground
                    .transition(.opacity.animation(.easeInOut))
            } else {
                ZStack {
                    Color(uiColor: .systemGroupedBackground)
                        .ignoresSafeArea()
                    
                    GeometryReader { proxy in
                        ZStack {
                            Circle()
                                .fill(Color.blue.opacity(0.15))
                                .frame(width: proxy.size.width * 0.8)
                                .offset(x: -proxy.size.width * 0.1, y: -proxy.size.height * 0.2)
                                .blur(radius: 15)
                                
                            
                            Circle()
                                .fill(Color.teal.opacity(0.15))
                                .frame(width: proxy.size.width * 0.8)
                                .offset(x: proxy.size.width * 0.2, y: proxy.size.height * 0.4)
                                .blur(radius: 15)
                            
                            Circle()
                                .fill(Color.indigo.opacity(0.1))
                                .frame(width: proxy.size.width * 0.5)
                                .offset(x: -proxy.size.width * 0.2, y: proxy.size.height * 0.5)
                                .blur(radius: 15)
                            
                            Circle()
                                .fill(Color.cyan.opacity(0.1))
                                .frame(width: proxy.size.width * 0.4)
                                .offset(x: proxy.size.width * 0.5, y: proxy.size.height * 0.1)
                                .blur(radius: 15)
                                
                        }
                    }
                }
                .transition(.opacity.animation(.easeInOut))
            }
        }
        .animation(.easeInOut(duration: 0.5), value: theme)
    }
}

struct HomeActionButton: View {
    let title: String; let subtitle: String; let icon: String; let color: Color
    var body: some View {
        HStack(spacing: 20) {
            ZStack {
                Circle().fill(color.opacity(0.12)).frame(width: 54, height: 54)
                Image(systemName: icon).font(.title3).foregroundStyle(color)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.headline).foregroundStyle(.primary)
                Text(subtitle).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            Image(systemName: "chevron.right").font(.system(size: 14, weight: .semibold)).foregroundStyle(.blue.opacity(0.3))
        }
        .padding(18).background(Color(uiColor: .secondarySystemBackground).opacity(0.5)).clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
}

struct ManualInputSheet: View {
    @Binding var text: String; let onCommit: () -> Void; @Environment(\.dismiss) var dismiss
    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 16) {
                TextEditor(text: $text).padding(12).scrollContentBackground(.hidden).background(Color(uiColor: .secondarySystemGroupedBackground)).clipShape(RoundedRectangle(cornerRadius: 16)).padding(.horizontal)
                Button(action: onCommit) {
                    Text("Create Flashcard").font(.headline).frame(maxWidth: .infinity).padding().background(text.isEmpty ? .gray : .blue).foregroundStyle(.white).clipShape(Capsule())
                }.disabled(text.isEmpty).padding()
            }.navigationTitle("Manual Input").toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } } }
        }.presentationDetents([.medium])
    }
}

#Preview {
    AmbientBackground()
}
